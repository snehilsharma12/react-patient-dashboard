Built the test as a react app. 
To run, use npm to build and start. Make sure all the dependencies are installed.
the HTML is in './src/App.js' file as it is in JSX. The style sheet is in './src/App.css'. 
The blood pressure graph is a component and is located in './src/BloodPressureChart.js'.
